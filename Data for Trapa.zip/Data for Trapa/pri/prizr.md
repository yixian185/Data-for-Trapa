setwd('/Users/liyixian1990/Desktop/pri')
library(tidyverse)
library(prioritizr)

library(rgdal)
library(raster)
library(rgeos)
library(mapview)
library(units)
library(scales)
library(assertthat)
library(gridExtra)

pu_data2<-readOGR('slope.shp')
veg_data2<-stack(c('He.tif')) 


library(lpsymphony)
p1<-problem(pu_data2,veg_data2,cost_column='meamslopem')%>%
  add_min_set_objective()%>%
  #add_boundary_penalties(penalty = 1) %>%#这个很慢
  add_relative_targets(0.2)%>%
  add_binary_decisions()%>%
  add_lpsymphony_solver(verbose = F)
s1<-solve(p1)

plot(st_as_sf(s1[, "solution_1"]), main = "Prioritization",
     pal = c("white", "#3C5488FF"))#颜色和下边对应，这个图是首要保护区

irrep_s1 <- eval_ferrier_importance(p1, s1["solution_1"])
print(irrep_s1)
irrep_s1$plot_total <- irrep_s1$total
irrep_s1$plot_total[s1$solution_1 < 0.5] <- NA_real_

library(scico)
library(paletteer)
scico_palette_show()
e<-paletteer_c("scico::brocO", n = 12)#n的个数注意调，这仅仅是个颜色板
#colors <- colorRampPalette(c("#7E6148FF", "#91D1C2FF"))(13)

plot(st_as_sf(irrep_s1[, "plot_total"]), main = "Overall importance",pal=e)
#这个图是首要保护区里的重要区域
dev.off()
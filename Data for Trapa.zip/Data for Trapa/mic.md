setwd('/Users/liyixian1990/Desktop/mic')
library(minerva) 
library(ggplot2)
library(reshape2)

tdiv<- read.csv("t6.csv",header=T,row.names=1)
tenv<-read.csv("t41hel.csv",header=T,row.names=1)

tdiv<-t(tdiv)

tdiv <- tdiv[rowSums(tdiv)>0,]

mat1 <- match(rownames(tenv),colnames(tdiv))
tdiv <- tdiv[,mat1]

mat2 <- match(colnames(tdiv),rownames(tenv))
tenv <- tenv[mat2,]

mic <- c()
for (i in 1:nrow(tdiv)){  
  res = c()
  for (j in 1:ncol(tenv)){ 
    res = c(res,mine(as.numeric(tdiv[i,]),tenv[,j])$MIC)
  }
  mic = rbind(mic,res)
}

colnames(mic) <- colnames(tenv)
rownames(mic) <- rownames(tdiv)
head(mic)

per <-c()
for (k in 1:ncol(mic)){ # k = 1
  per = cbind(per,table(mic[,k]>0.4)[2]*100/nrow(mic))#0.4代表显著相关
}

colnames(per)<-colnames(tenv)
rownames(per)<-"percent"

per.gg<-melt(per,
             id.vars = c("percent"),
             measure.vars = colnames(per),
             variable.name='tenv',
             value.name='Percentage')
per.gg
p<-ggplot(per.gg)+
  geom_bar(aes(x=Var2,y=Percentage),stat="identity")+#这里per.gg用的是percentage
  coord_flip()+labs(title="tgen (MIC>0.4)",x="Factors",y="Percentage")+
  theme_bw()
p
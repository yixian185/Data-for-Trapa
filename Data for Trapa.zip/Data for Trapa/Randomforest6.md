setwd('/Users/liyixian1990/Desktop/DDI') #输出6*13
library(linkET)
library(vegan)
env<-read.csv('t41.csv',row.names=1)
h.env<-decostand(env,method='hellinger')#环境做hellinger转换
gen<-read.csv('t6.csv',row.names=1)


library(ggplot2)
library(ggsci)


rf <- random_forest(gen, h.env)

p <- correlate(gen, h.env) %>% 
  qcorrplot(extra_mat = list(Importance = rf$importance,
                             pvalue = rf$p),
            fixed = FALSE) +
  geom_tile(colour = "grey", size = 0.1) +
  geom_point(aes(size = Importance), fill = NA, shape = 16,color='#00A087FF',
             data = function(data) data[data$pvalue < 0.05, , drop = FALSE]) +
  #scale_fill_gsea()+

  #scale_fill_gradientn(colours = RColorBrewer::brewer.pal(9, "YlGnBu"))+
  scale_fill_gradient2(low='#132C3A',high='#9E342E')+
  #scale_fill_gradientn(colors=mypal)+


  theme(text=element_text(family='Arial',face='bold',size=16,angle = 0))

p

#mypalred<-pal_material('amber',alpha=0.9)(5)
#mypalred
#library(scales)
#show_col(mypalred)

#mypal<-c('#132C3A', '#3B5968', '#6D868E', '#A6B4BA', '#D8DFDF', '#FFFFFF',#'#F1E0DF', '#E1B8B6','#D1898B','#B75A58','#9E342E')
#show_col(mypal)


library(tidyverse)
dat = rf$explained %>% arrange(explained)
dat$name = factor(dat$name,levels = dat$name)



p2 <- ggplot(dat, aes(explained, name)) +
  geom_col(fill = "#3C5488FF") +
  theme_bw()+
  theme(panel.grid=element_blank(),
        panel.border = element_rect(color='black',size=1.5))+
  theme(axis.text.y = element_blank(),
        axis.ticks.y = element_blank(),
        axis.title.y = element_blank(),
        axis.text.x = element_text(family='Arial',color='black'))+
  theme(text=element_text(family='Arial',face='bold',size=16))+
  xlab('Explained')+
  theme(axis.title.x = element_text(size = 16, color = 'black', face = "bold"))
p2

library(aplot)

p2  %>%
  aplot::insert_left(p, width=3)

dev.off()
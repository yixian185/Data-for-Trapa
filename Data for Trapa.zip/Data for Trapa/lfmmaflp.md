setwd('/Users/liyixian1990/Desktop/test2')
library(lfmm)
library(data.table)
loci<-read.csv('vgen.csv',row.names=1)
env<-read.csv('venv.csv',row.names=1)
mod.lfmm <- lfmm_ridge(Y = loci, 
                       X = env, 
                       K = 2)
pv <- lfmm_test(Y = loci, 
                X = env, 
                lfmm = mod.lfmm, 
                calibrate = "gif")
pvalues <- pv$calibrated.pvalue#要这个P值写出来csv，用在下一步cmplot，后边的其实用处不大
write.csv(pvalues,'target2.csv')

library(CMplot)
msp<-read.csv('genwas.csv',row.names=1)
CMplot(msp,plot.type="q",col=c("#7E6148FF"),
       threshold=0.001,ylab.pos=2,signal.pch=c(19,6,4),signal.cex=1.2,
       signal.col="#EE4C97FF",conf.int=TRUE,box=FALSE,multracks=TRUE,
       cex.axis=2,file="jpg",memo="",dpi=300,file.output=F,
       verbose=TRUE,ylim=c(0,8),width=5,height=5)#qqplot,注意threshold设置
SNPs <- list(
  msp$SNP[msp$env<0.001])
CMplot(msp,col='#20854EFF',plot.type="m", multracks=TRUE, threshold=c(0.001,0.005),#合并
       threshold.lty=c(1,2), threshold.lwd=c(1,1), 
       threshold.col=c("black","#ADB6B6FF"), amplify=TRUE,bin.size=1e6, 
       chr.den.col=c("#0099B4FF", "#925E9FFF"),
       signal.col=c("#EE4C97FF"),signal.cex=c(1,1),
       file="jpg",memo="",dpi=300,file.output=F,verbose=TRUE,#这里先T一下，出3个，再F
       highlight=SNPs, highlight.text=SNPs, highlight.text.cex=1.4)

dev.off()
setwd('/Users/liyixian1990/Desktop/DDI')
library(poppr)
trapa<-read.genalex('tamova.csv')
splitStrata(trapa)<-~pop/region/sp
trapa
setPop(trapa)<-~pop#pop作为分组标准
trapadiversity <- poppr(trapa)
trapadiversity
write.csv(trapadiversity,file='trapadiversity.csv')
trapaamova<-poppr.amova(trapa,~region/sp)
trapaamova#这个csv写不出来，记事本复制